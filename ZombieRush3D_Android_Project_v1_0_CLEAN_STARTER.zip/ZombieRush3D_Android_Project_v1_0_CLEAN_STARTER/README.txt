Zombie Rush 3D Android APK Projesi v1.0 CLEAN STARTER

İlk oyun temeli:
- 3D tarzı koşu sahnesi
- Koşan ana karakter
- Görünen silah sistemi
- Zombiler sahnede koşarak gelir
- Ateş etme, muzzle flash, basit ses efekti
- Coin sistemi
- Market / satın alma
- Envanter sistemi
- 4 silah: Pistol, Uzi, Shotgun, Rifle
- Can, skor, rekor kaydı
- Mobil dokunmatik kontrol
- WebView/Canvas tabanlı temiz APK starter

GitHub Actions:
ZIP: ZombieRush3D_Android_Project_v1_0_CLEAN_STARTER.zip
Artifact: ZombieRush3D-v1-0-CLEAN-STARTER-debug-apk
