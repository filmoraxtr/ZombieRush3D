Zombie Rush 3D Android APK Projesi v1.2 REAL GAMEPLAY VISUAL FIX

v1.1 telefonda bulunan sorun:
- Oyun ekranı açılıyordu ama sahne boş görünüyordu.
- Karakter ve zombiler net görünmüyordu.
- Oyun içi sağ/sol/ateş kontrolleri tepki vermiyordu.

v1.2 çözümü:
- Oyun sahnesi yeniden kuruldu.
- Karakter ekranda büyük ve net çiziliyor.
- Silah karakterin elinde görünür hale getirildi.
- Zombiler oyun başında direkt sahneye eklendi.
- Zombiler daha büyük ve görünür çiziliyor.
- Ateş efekti daha görünür hale getirildi.
- Sağ/sol/ateş kontrolleri pointerdown/pointerup ile güçlendirildi.
- Touch + Pointer + Click birlikte destekleniyor.
- Market ve envanter sistemi korunur.

GitHub Actions:
ZIP: ZombieRush3D_Android_Project_v1_2_REAL_GAMEPLAY_VISUAL_FIX.zip
Artifact: ZombieRush3D-v1-2-REAL-GAMEPLAY-VISUAL-FIX-debug-apk
