Zombie Rush 3D Android APK Projesi v3.0 ATMOSPHERE FPS REBUILD

Hedef:
- Into the Dead tarzını referans alan, birebir kopya olmayan, first-person atmosferli zombi survival shooter.

Yenilikler:
- Eski tam karakter görünümü kaldırıldı; first-person silah görünümü getirildi.
- Elde görünen daha detaylı silah modeli çizildi.
- Silah recoil, muzzle flash ve reload göstergesi güçlendirildi.
- Yoğun sis, gece, ay, ev/çit/direk/araba silüetleri ve karanlık yol atmosferi eklendi.
- Mesafe sayacı eklendi.
- Mermi / şarjör / reload sistemi güçlendirildi.
- Crosshair ve hit marker eklendi.
- Walker / Runner / Brute / Crawler zombi tipleri eklendi.
- Zombiler daha karanlık ve tehditkar çizildi.
- Kan, hit spark, damage flash ve kamera shake efektleri güçlendirildi.
- Coin sadece zombi öldürünce gelir.
- Market ve envanter sistemi korundu.
- Touch + pointer kontroller korunur.

GitHub Actions:
ZIP: ZombieRush3D_Android_Project_v3_0_ATMOSPHERE_FPS_REBUILD.zip
Artifact: ZombieRush3D-v3-0-ATMOSPHERE-FPS-REBUILD-debug-apk
