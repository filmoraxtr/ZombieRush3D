Zombie Rush 3D Android APK Projesi v2.0 CINEMATIC ZOMBIE SURVIVAL

Hedef:
- Into-the-Dead tarzını referans alan, ama birebir kopya olmayan sinematik zombi koşu/ateş oyunu temeli.

Yenilikler:
- Daha karanlık sinematik atmosfer.
- Sisli yol, kırmızı tehlike ışıkları ve karanlık çevre hissi.
- Ana karakter daha detaylı çizildi.
- Silah karakterin elinde daha gerçekçi görünüyor.
- Silah geri tepme animasyonu eklendi.
- Daha gerçekçi zombi çizimleri eklendi.
- Walker / Runner / Brute zombi tipleri eklendi.
- Zombi vurulma ve kan efekti eklendi.
- Coin artık sadece zombi öldürünce kazanılır.
- Şarjör / mermi sistemi eklendi.
- Silah marketi ve envanter korundu.
- Ateş sesi, muzzle flash ve ekran sarsıntısı güçlendirildi.

GitHub Actions:
ZIP: ZombieRush3D_Android_Project_v2_0_CINEMATIC_ZOMBIE_SURVIVAL.zip
Artifact: ZombieRush3D-v2-0-CINEMATIC-ZOMBIE-SURVIVAL-debug-apk
