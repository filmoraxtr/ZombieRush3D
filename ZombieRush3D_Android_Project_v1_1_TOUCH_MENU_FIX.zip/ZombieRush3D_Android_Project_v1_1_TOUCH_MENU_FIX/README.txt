Zombie Rush 3D Android APK Projesi v1.1 TOUCH MENU FIX

v1.0 telefonda bulunan sorun:
- Oyun açılıyordu ama menü / market / envanter butonları tepki vermiyordu.
- Bu Android WebView içinde canvas / overlay / dokunmatik event çakışmasından kaynaklanabilir.

v1.1 çözümü:
- Canvas pointer-events kapatıldı, menü dokunmaları engellemez.
- Screen / controls / pause katman z-index değerleri güçlendirildi.
- Ana butonlarda onclick yerine güvenli tap() sistemi eklendi.
- Touchstart/touchend ve click birlikte desteklendi.
- Oyuna başla / Market / Envanter / Geri / Pause butonları güçlendirildi.
- Dinamik Market ve Envanter butonları addEventListener ile bağlandı.

GitHub Actions:
ZIP: ZombieRush3D_Android_Project_v1_1_TOUCH_MENU_FIX.zip
Artifact: ZombieRush3D-v1-1-TOUCH-MENU-FIX-debug-apk
